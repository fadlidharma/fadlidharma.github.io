// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define(["dojo/_base/html"],function(a){return{a11y_initAriaAttrs:function(){var b=this["aria-labelledby"];b&&(a.removeAttr(this.domNode,"aria-labelledby"),a.setAttr(this.opacitySlider.focusNode,"aria-labelledby",b))}}});